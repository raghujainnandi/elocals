package com.eLocals.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.eLocals.Entity.User;
import com.eLocals.Repository.UserRepository;

@Controller

public class SecurityController {
	
	@Autowired
	BCryptPasswordEncoder  bCryptEncoder;
	
	@Autowired
	UserRepository userrepository;
	
	@RequestMapping(value="/register",method=RequestMethod.GET)
	public String register(Model model)
	{
		User user=new User();
		model.addAttribute("user",user);
		return "register";
	}
	

	@RequestMapping(value="savesignup",method=RequestMethod.POST)
	public String savepass(Model model, User user)
	{
		user.setPassword(bCryptEncoder.encode(user.getPassword()));
		userrepository.save(user);
		return "login";
		
	}
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String login(Model model)
	{
		return "login";
	}
	
	@RequestMapping(value="/validate",method=RequestMethod.POST)
	public String validate(@RequestParam("email") String email,@RequestParam("password")String password,Model model)
	{
		User user = userrepository.findByEmail(email);
		String db_pass = user.getPassword();
		String new_pass = bCryptEncoder.encode(password);
		
		if(db_pass.equals(new_pass))
		{
			return "welcome";
		}
		else
		{
			model.addAttribute("msg","Invalid Credentials ..Please Enter Valid Credentials");
		}
		return "login";
		
	}
	
}



