package com.eLocals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ELocalsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ELocalsApplication.class, args);
	}

}
